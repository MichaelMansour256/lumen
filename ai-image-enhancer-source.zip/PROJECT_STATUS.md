# Project status

Last update: 2026-11-17

## Phases
- [x] 1 Architecture
- [x] 2 Frontend workspace (upload, queue, settings, compare viewer, downloads)
- [x] 3 Backend (FastAPI, validation, storage, SQLite, job queue)
- [x] 4 AI upscaling (Real-ESRGAN via spandrel, tiled, staged 8x/16x)
- [x] 5 Restoration (GFPGAN/CodeFormer faces, classical clean-up and colour)
- [x] 6 Comparison editor, manual controls, batch + ZIP
- [x] 7 GPU memory management (one model on GPU, FP16, OOM tile back-off, CPU fallback)
- [ ] 8 Verification on the Windows machine  <-- NEXT

## Verified (33 automated tests, no PyTorch needed: `backend/tests/test_pipeline.py`)
Settings validation, scaling plans and limits, seamless tiling, upload validation (formats, corrupt
files, size, EXIF rotation, alpha), PNG/JPG/WebP export, storage path safety, every manual control,
analysis heuristics, full pipeline output dimensions (1x-16x, percent, custom) with a stand-in 4x
model, job lifecycle (progress, failure, retry, cancel, timeout), cleanup.
Frontend: type-checked against stub typings only.

## NOT yet verified (needs setup.bat on Windows, then run_tests.bat)
- setup.bat / start.bat themselves
- Real model inference: Real-ESRGAN 2x/4x/8x, denoise blending, FP16, CPU fallback (`tests/test_models.py`)
- GFPGAN face restoration + YuNet detection (needs `backend/tests/assets/face.jpg`)
- CodeFormer and SwinIR (optional models)
- HTTP API tests (`tests/test_api.py`, need FastAPI)
- Frontend `npm install` + `next build`, and the UI in a browser

## Next task
Run setup.bat, then run_tests.bat; read logs\setup.log, logs\environment.txt,
logs\test_backend.log, logs\test_frontend.log and fix whatever fails.

## Commands
- Install: `setup.bat`   Start: `start.bat`   Tests: `run_tests.bat`
- Backend tests only: `cd backend && .venv\Scripts\python.exe -m pytest tests -v -s`
- Models: `cd backend && .venv\Scripts\python.exe scripts\download_models.py --list`
