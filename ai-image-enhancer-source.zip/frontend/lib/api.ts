import type {
  ApiErrorBody, EnhanceSettings, ExportFormat, ImageRecord, Job, Plan, SystemInfo,
} from "./types";

export const API_URL = (process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8000").replace(/\/$/, "");

export class ApiError extends Error {
  code: string;
  retryable: boolean;
  details: ApiErrorBody["details"];

  constructor(body: Partial<ApiErrorBody> & { message: string }) {
    super(body.message);
    this.code = body.code ?? "error";
    this.retryable = body.retryable ?? false;
    this.details = body.details ?? {};
  }
}

const OFFLINE = "Cannot reach the enhancement server. Make sure the backend is running (start.bat).";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_URL}${path}`, init);
  } catch {
    throw new ApiError({ code: "offline", message: OFFLINE, retryable: true });
  }
  if (!res.ok) throw await toError(res);
  return (await res.json()) as T;
}

async function toError(res: Response): Promise<ApiError> {
  try {
    const body = await res.json();
    if (body?.error?.message) return new ApiError(body.error);
  } catch {
    /* not JSON */
  }
  return new ApiError({ code: "http_error", message: `Request failed (${res.status}).` });
}

const json = (body: unknown): RequestInit => ({
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body),
});

export const absoluteUrl = (path: string) => `${API_URL}${path}`;

export const getSystem = () => request<SystemInfo>("/api/system");

export async function uploadImages(files: File[]) {
  const form = new FormData();
  files.forEach((file) => form.append("files", file, file.name));
  return request<{ images: ImageRecord[]; errors: { name: string; error: ApiErrorBody }[] }>(
    "/api/images", { method: "POST", body: form });
}

export const deleteImage = (id: string) =>
  request<{ deleted: string }>(`/api/images/${id}`, { method: "DELETE" });

export const getPlan = (imageId: string, settings: EnhanceSettings, format: ExportFormat,
                        quality: number, signal?: AbortSignal) =>
  request<Plan>("/api/plan", { ...json({ image_id: imageId, settings, format, quality }), signal });

export const createJobs = (imageIds: string[], settings: EnhanceSettings) =>
  request<{ jobs: Job[]; errors: { image_id: string; error: ApiErrorBody }[] }>(
    "/api/jobs", json({ image_ids: imageIds, settings }));

export const getJobs = (ids: string[]) =>
  request<{ jobs: Job[] }>(`/api/jobs?ids=${ids.join(",")}`);

export const retryJob = (id: string, device?: "auto" | "cpu") =>
  request<Job>(`/api/jobs/${id}/retry${device ? `?device=${device}` : ""}`, { method: "POST" });

export const cancelJob = (id: string) =>
  request<{ cancelled: boolean }>(`/api/jobs/${id}/cancel`, { method: "POST" });

export const resultUrl = (jobId: string) => `${API_URL}/api/jobs/${jobId}/result`;

function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

async function download(path: string, init: RequestInit | undefined, fallbackName: string) {
  let res: Response;
  try {
    res = await fetch(`${API_URL}${path}`, init);
  } catch {
    throw new ApiError({ code: "download_failed", message: "Download failed: the server did not respond.", retryable: true });
  }
  if (!res.ok) {
    const err = await toError(res);
    throw new ApiError({ code: err.code, message: `Download failed: ${err.message}`, retryable: true });
  }
  const blob = await res.blob();
  if (blob.size === 0) {
    throw new ApiError({ code: "download_failed", message: "Download failed: the file was empty.", retryable: true });
  }
  const match = /filename="([^"]+)"/.exec(res.headers.get("Content-Disposition") ?? "");
  saveBlob(blob, match?.[1] ?? fallbackName);
}

export const downloadResult = (jobId: string, format: ExportFormat, quality: number, name: string) =>
  download(`/api/jobs/${jobId}/result?format=${format}&quality=${quality}&download=true`, undefined,
           `${name.replace(/\.[^.]+$/, "")}_enhanced.${format}`);

export const downloadZip = (jobIds: string[], format: ExportFormat, quality: number) =>
  download("/api/download/zip", json({ job_ids: jobIds, format, quality }), "enhanced_images.zip");
