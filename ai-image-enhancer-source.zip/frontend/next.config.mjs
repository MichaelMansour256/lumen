/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // ESLint is not part of this project; type checking still runs during `next build`.
  eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;
